﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Workers;

/**
* 10/20/2021
* CSC 253
* Nicholas Baxley
* Add and displays employees from a list.
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        // List of all employees for global use.
        List<ProductionWorker> employees = new List<ProductionWorker>();

        public Form1()
        {
            InitializeComponent();
        }

        // The close button.
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Adds an employee to the output list.
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            // Add variable and validate them
            string name = textBoxName.Text;
            bool numberFlag = int.TryParse(textBoxNumber.Text, out int number);
            bool shiftFlag = int.TryParse(textBoxShift.Text, out int shift) && (shift == 1 || shift == 2);
            bool payRateFlag = decimal.TryParse(textBoxPayrate.Text, out decimal payRate);

            // Tells user if item didnt validate.
            if (!numberFlag)
            {
                listBoxOutput.Items.Add("Employee number must be an interger!");
            }
            if (!shiftFlag)
            {
                listBoxOutput.Items.Add("Employee Shift must 1 or 2!");
            }
            if (!payRateFlag)
            {
                listBoxOutput.Items.Add("Employee Payrate must be a decimal!");
            }

            // If all validate, adds employees to list.
            if (numberFlag && shiftFlag && payRateFlag)
            {
                employees.Add(new ProductionWorker(name, number, shift, payRate));
                listBoxOutput.Items.Add("Added Employee!");
            }           
        }

        // Clears the output box and displays all employees.
        private void buttonEmployees_Click(object sender, EventArgs e)
        {
            listBoxOutput.Items.Clear();
            foreach (ProductionWorker person in employees)
            {
                listBoxOutput.Items.Add("----------------------");
                listBoxOutput.Items.Add(person.name);
                listBoxOutput.Items.Add(person.number);

                if (person.shift == 1)
                {
                    listBoxOutput.Items.Add("Day Shift");
                }
                else
                {
                    listBoxOutput.Items.Add("Night Shift");
                }
                
                listBoxOutput.Items.Add(person.payrate);
                listBoxOutput.Items.Add("");
            }
        }
    }
}
