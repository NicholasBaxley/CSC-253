﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Areas;


/**
* 8/27/21
* CSC 253
* Nicholas Baxley
* Finds the area of a shape.
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

  
        //Close button
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Changes the shown buttons to the first buttons layout
        private void buttonCircleSelect_Click(object sender, EventArgs e)
        {
            buttonReset();
            buttonCircleSelect.Enabled = false;
            textBoxInput2.Enabled = false;
            labelInput1.Text = "Radius";
            labelInput2.Text = "";

        }

        //Changes the shown buttons to the second buttons layout
        private void buttonRectangleSelect_Click(object sender, EventArgs e)
        {
            buttonReset();
            buttonRectangleSelect.Enabled = false;
            labelInput1.Text = "Length";
            labelInput2.Text = "Width";
        }

        //Changes the shown buttons to the third buttons layout
        private void buttonCylinderSelect_Click(object sender, EventArgs e)
        {
            buttonReset();
            buttonCylinderSelect.Enabled = false;
            labelInput1.Text = "Radius";
            labelInput2.Text = "Height";
        }

        //Resets the buttons that are turned off
        public void buttonReset()
        {
            buttonCircleSelect.Enabled = true;
            buttonCylinderSelect.Enabled = true;
            buttonRectangleSelect.Enabled = true;
            textBoxInput2.Enabled = true;
            textBoxInput1.Text = "";
            textBoxInput2.Text = "";
        }

        // Clears a textbox's default invalid message.
        private void textClear(TextBox inputBox)
        {
            if (inputBox.Text == "Not Valid!")
            {
                inputBox.Text = "";
            }
        }

        // Writes an invalid message onto the textbox
        private void invalidText(TextBox inputbox)
        {
            string text = "Not Valid!";
            inputbox.Text = text;
        }

        //Submit button determines which method to call.
        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            // If Circle Selected
            if (buttonCircleSelect.Enabled == false)
            {
                try
                {
                    double radius = Double.Parse(textBoxInput1.Text);
                    // METHOD OVERLOAD 1
                    string output = Area.Convert(radius).ToString("N");
                    listBoxOutput.Items.Add("Circle radius of " + radius + " = " + output + "."); 
                }
                catch (Exception)
                {
                    invalidText(textBoxInput1);
                }
                
            }
            // If Rectangle Selected
            else if (buttonRectangleSelect.Enabled == false)
            {
                try
                {
                    float width = float.Parse(textBoxInput1.Text);
                    float length = float.Parse(textBoxInput2.Text);
                    // METHOD OVERLOAD 2
                    string output = Area.Convert(width, length).ToString("N");
                    listBoxOutput.Items.Add("Rectangle with " + width + " and " + length + " = " + output + ".");
                }
                catch (Exception)
                {
                    invalidText(textBoxInput1);
                    invalidText(textBoxInput2);
                }
            }
            // If Cylinder Selected
            else
            {
                try
                {
                    double radius = Double.Parse(textBoxInput1.Text);
                    double height = Double.Parse(textBoxInput2.Text);
                    // METHOD OVERLOAD 3
                    string output = Area.Convert(radius, height).ToString("N");
                    listBoxOutput.Items.Add("Cylinder with " + radius + " and " + height + " = " + output + ".");
                }
                catch (Exception)
                {
                    invalidText(textBoxInput1);
                    invalidText(textBoxInput2);
                }
            }
        }

        //Clears invalid text in taxtbox1
        private void textBoxInput1_Click(object sender, EventArgs e)
        {
            textClear(textBoxInput1);
        }

        //Clears invalid text in textbox2
        private void textBoxInput2_Click(object sender, EventArgs e)
        {
            textClear(textBoxInput2);
        }
    }
}