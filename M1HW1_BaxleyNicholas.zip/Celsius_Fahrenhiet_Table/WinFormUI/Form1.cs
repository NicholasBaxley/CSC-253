﻿using System;  
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Temperture;
/**
* 8/19/21
* CSC 253
* Nicholas Baxley
* Converting Celsius to Fahrenheit
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Makes the header for the conversion box
            conversionBox.Items.Add(String.Format("{0,7} {1, 7} {2, 7}",
                                                    "C", "|", "F"));
            conversionBox.Items.Add("---------------------------------");

            // Fills the conversionBox up with conversions from 0-20
            for (int cel = 0; cel < 21; cel++)
            {
                conversionBox.Items.Add(String.Format("{0, -7} {1, 7} {2, -7}",
                                                        cel, "|", Temperture.Conversion.celToFah(cel)));
            }
        }

        // Close button for the program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
