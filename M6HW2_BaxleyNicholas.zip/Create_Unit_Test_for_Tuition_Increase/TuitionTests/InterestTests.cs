﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tuition;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuition.Tests
{
    [TestClass()]
    public class InterestTests
    {
        [TestMethod()]
        public void YearlyTest()
        {
            double expected = 11000;
            double actual;
            double price = 10000;
            double percent = .10;

            actual = price * (1.00 + percent);

            Assert.AreEqual(expected, actual);
        }
    }
}