﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workers
{
    public class TeamLeader : ProductionWorker
    {
        public decimal monthlyBonus { get; set; }
        public int trainedHours { get; set; }
        public int attendedHours { get; set; }

        public TeamLeader(decimal MonthlyBonus, int TrainedHours, int AttendedHours, string Name, int Number, int Shift, decimal Payrate) 
                  : base (Name, Number, Shift, Payrate)
        {
            monthlyBonus = MonthlyBonus;
            trainedHours = TrainedHours;
            attendedHours = AttendedHours;
        }
    }
}
