﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Words
{
    public class Word
    {
        // Seperates word at their capitols
        // I literally couldnt think of any other way to do this.
        public static string Separate(string sentence)
        {
            string newSentence = sentence;
            int count = 0;

            for (int index = 0; index < sentence.Count() - 1; index++)
            {
                if (char.IsUpper(sentence[index]))
                {
                    newSentence = newSentence.Insert(index + count, " ");
                    count++;
                }
            }
            newSentence = newSentence.TrimStart().ToLower();
            newSentence = char.ToUpper(newSentence[0]) + newSentence.Substring(1);

            return newSentence;

        }
    }
}
