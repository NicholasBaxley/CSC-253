﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringExtension
{
    public class Count
    {
        // Takes a string and returns the an interger of the amount of words in it.
        public static int Words(string input)
        {
            return input.Trim().Split(' ').Length;
        }
    }
}
