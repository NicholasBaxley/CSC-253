﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Numbers;

/**
* 9/15/21
* CSC 253
* Nicholas Baxley
* Reads a file and tells you how many numbers are in there and what they add up to
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Close button
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        // Reads all numbers from the number file and adds them together plus counts their total and displays it to the output box.
        private void buttonReadFile_Click(object sender, EventArgs e)
        {
            try
            {
                List<int> numbers = new List<int>();
                char delim = ',';
                StreamReader inputFile = File.OpenText("numbers.txt");

                // Grabs all of the numbers from the file
                string[] tokens = inputFile.ReadToEnd().Split(delim);

                // Turns every string number into an int number
                foreach (string item in tokens)
                {
                    numbers.Add(Int32.Parse(item));
                }

                listBoxOutput.Items.Add("There are " + numbers.Count() + " numbers in this file.");
                listBoxOutput.Items.Add("They add up to " + Calculation.AddTogether(numbers) + " in total.");
                listBoxOutput.Items.Add("");

                inputFile.Close();
            }
            catch (FormatException)
            {
                listBoxOutput.Items.Add("A non-number is in your file.");
            }
            catch (IOException)
            {
                listBoxOutput.Items.Add("Failed to load file.");
            }
            catch (Exception)
            {
                listBoxOutput.Items.Add("Unknown Error.");
            }
        }
    }
}
