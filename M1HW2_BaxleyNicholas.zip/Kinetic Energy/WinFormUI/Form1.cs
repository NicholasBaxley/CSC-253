﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using KineticEnergy;

/**
* 8/19/21
* CSC 253
* Nicholas Baxley
* Converts mass and velocity into kinetic energy
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Closes the program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Grabs the input in velocity and mass textbox then calculates the kinetic and displays it
        private void submitButton_Click(object sender, EventArgs e)
        {
            Boolean realMass = false;
            Boolean realVelocity = false;
            double mass = 0;
            double velocity = 0;

            // Test mass to see if its a double
            try
            {
                mass = Double.Parse(massInput.Text);
                realMass = true;
            }
            catch (Exception)
            {
                invalidText(massInput);        
            }

            // Test velocity to see if its a double
            try
            {
                velocity = Double.Parse(velocityInput.Text);
                realVelocity = true;
            }
            catch (Exception)
            {
                invalidText(velocityInput);
            }

            // If both test succeed converts mass and velocity to kinetic energy.
            if (realMass && realVelocity)
            {
                double kinetic = KineticEnergy.Conversions.massVelocityToKinetic(mass, velocity);
                kinecticOutput.Items.Add(mass + " kilograms and " + velocity + " mps = " + kinetic + " J.");
            }

        }

        //Clears the textboxes when you click on them.
        private void massInput_MouseClick(object sender, MouseEventArgs e)
        {
            textClear(massInput);
        }
        private void velocityInput_MouseClick(object sender, MouseEventArgs e)
        {
            textClear(velocityInput);
        }
    
        // Clears a textbox's default message.
        private void textClear(TextBox inputBox)
        {
            if (inputBox.Text == "Not Valid!")
            {
                inputBox.Text = "";
            }      
        }

        // Writes an invalid message onto the textbox
        private void invalidText(TextBox inputbox)
        {
            string text = "Not Valid!";
            inputbox.Text = text;
        }     
    }
}
