﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Workers;

/**
* 10/20/2021
* CSC 253
* Nicholas Baxley
* Demonstrates a supervisor class that uses an employee parent class
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Closes the program.
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Creates and prints out 2 supervisor objects.
        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            Supervisor visor1 = new Supervisor("Jared", 1001, 2000, 45000);
            Supervisor visor2 = new Supervisor("Michael", 1002, 2000, 47500);
            List<Supervisor> supervisors = new List<Supervisor>() {visor1, visor2};

            foreach (Supervisor visor in supervisors)
            {
                listBoxOutput.Items.Add($"Name: {visor.name}");
                listBoxOutput.Items.Add($"Employee ID: {visor.number}");
                listBoxOutput.Items.Add($"Salary: {visor.annualSalary}");
                listBoxOutput.Items.Add($"Bonus: {visor.annualBonus}");
                listBoxOutput.Items.Add("");
            }
        }
    }
}
