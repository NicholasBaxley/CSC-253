﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Numbers
{
    public class RandomNumber
    {
        // Generates a requested amount of numbers bewteem 0 - 100 and returns them in a list
        public static List<int> Hundred(int writeTimes)
        {
            List<int> numbers = new List<int>();
            Random rand = new Random();
            for (int index = 0; index < writeTimes; index++)
            {          
                numbers.Add(rand.Next(101));
            }
            return numbers;
        }
    }
}
