﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    [TestClass()]
    public class RetailTests
    {
        [TestMethod()]
        public void GetPriceTest()
        {
            double expected = 7.50;
            double actual = Retail.GetPrice(5.00, .50);

            Assert.AreEqual(expected, actual);
        }
    }
}