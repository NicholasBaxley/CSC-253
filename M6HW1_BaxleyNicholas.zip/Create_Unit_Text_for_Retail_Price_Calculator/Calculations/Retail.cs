﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculations
{
    public class Retail
    {
        public static double GetPrice(double price, double percent)
        {
            double increase = price * percent;
            return increase + price;
        }
    }
}
