﻿using Animals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome!");
            Console.WriteLine("--------------------------");
            bool loop;
            List<Pet> pets = new List<Pet>();

            do
            {
                loop = false;
                pets = AskForAnimals();
                PrintAnimals(pets);
                Console.WriteLine("Would you like to continue? (y = Yes, anything else = No)");
                if (Console.ReadLine().ToLower() == "y")
                {
                    loop = true;
                }

            } while (loop);
        }

        // Displays all infomation about each animal in the provided list
        private static void PrintAnimals(List<Pet> animals)
        {
            Console.WriteLine("");
            for (int i = 0; i < animals.Count; i++)
            {
                Console.WriteLine($"{i + 1})");
                Console.WriteLine($"-----------------------------");
                Console.WriteLine($"Name: {animals[i].name}");
                Console.WriteLine($"Type: {animals[i].type}");
                Console.WriteLine($"Age:  {animals[i].age}");
                Console.WriteLine("");
            }

        }

        // Asks the user to give infomation about their pets and returns a list of all their pets
        private static List<Pet> AskForAnimals()
        {
            int animalCount = 0;
            bool animalFlag = false;

            while (!animalFlag || animalCount < 1)
            {
                Console.WriteLine("");
                Console.WriteLine("How many animals do you own?");
                animalFlag = int.TryParse(Console.ReadLine(), out animalCount);

                if (!animalFlag || animalCount < 1)
                {
                    Console.WriteLine("Please type a whole number above zero!");
                }
            }

            string name;
            string type;
            int age = -1;
            bool ageFlag;
            List<Pet> animals = new List<Pet>();

            for (int i = 0; i < animalCount; i++)
            {
                ageFlag = false;

                Console.WriteLine("");
                Console.WriteLine($"{i + 1})");
                Console.WriteLine("-----------------------------");
                Console.WriteLine("What is your animal's name?");
                name = Console.ReadLine();

                Console.WriteLine("");
                Console.WriteLine("What is your animal's species?");
                type = Console.ReadLine();


                while (!ageFlag || age < 0)
                {
                    Console.WriteLine("");
                    Console.WriteLine("What is your animal's age?");
                    ageFlag = int.TryParse(Console.ReadLine(), out age);

                    if (!ageFlag || age < 0)
                    {
                        Console.WriteLine("Please type a whole number above negative one!");
                    }
                }
                animals.Add(new Pet(name, type, age));
            }
            return animals;
        }

    }
}
