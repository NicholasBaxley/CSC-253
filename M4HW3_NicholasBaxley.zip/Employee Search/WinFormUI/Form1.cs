﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Validation;

/**
* 10/4/21
* CSC 253
* Nicholas Baxley
* Lets you search a name in a database and finds results
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.employeesTableAdapter.Fill(this.personnelDataSet.Employees);
        }

        // The close button
        private void Exitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Shows records for the name in the search box.
        private void searchButton_Click(object sender, EventArgs e)
        {
            string text = searchTextBox.Text;
            if (Validation.String.isText(text))
            {
                outputDataGridView.DataSource = employeesTableAdapter.SelectRowByName(text);
            }
            else
            {
                MessageBox.Show("Please only use letters to search for names.");
            }        
        }
    }
}
