﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workers
{
    public class ProductionWorker : Employee
    {
        int shift { get; set; }
        decimal payrate { get; set; }

        public ProductionWorker(string Name, int Number, int Shift, decimal Payrate) : base(Name, Number)
        {
            shift = Shift;
            payrate = Payrate;
        }
    }
}
