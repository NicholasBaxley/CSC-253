﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace People
{
    public class Person
    {
        public string fName { get; set; }
        public string mName { get; set; }
        public string lName { get; set; }
        public int age { get; set; }

        public Person()
        {
            fName = "";
            mName = "";
            lName = "";
            age = 0;
        }
        
        public Person(string personFirstName, string personMiddleName, string personLastName, int personAge)
        {
            fName = personFirstName;
            mName = personMiddleName;
            lName = personLastName;
            age = personAge;
        }
    }
}
