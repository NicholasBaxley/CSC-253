﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculations
{
    public class Retail
    {
        // Finds the retail price of an item
        public static double GetPrice(double price, double percent)
        {
            double increase = price * percent;
            return increase + price;
        }
    }
}
