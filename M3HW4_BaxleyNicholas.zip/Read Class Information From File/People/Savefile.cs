﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace People
{
    public class Savefile
    {
        public static string newPerson(Person person, bool newFile)
        {
            string message;
            try
            {
                StreamWriter output;
                // If they clicked newfile button
                if (newFile)
                {
                    output = File.CreateText("UserInformation.csv");
                    message = "New file created";
                }
                // If they clicked submit button
                else
                {
                    output = File.AppendText("UserInformation.csv");
                    message = "Added person successfully";
                }
                // Adding them to the file
                output.WriteLine($"{person.fName},{person.mName},{person.lName},{person.age}");
                output.Close();
                return message;
            }
            catch (Exception)
            {
                return "Failed to save";
            }          
        }
    }

}
