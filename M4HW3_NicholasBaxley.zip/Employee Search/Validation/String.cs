﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Validation
{
    public class String
    {
        //Checks to see if a string is 100% letters else returns false
        public static bool isText(string input)
        {
            bool output = true;
            foreach (char character in input)
            {
                if (!Char.IsLetter(character))
                {
                    output = false;
                }
            }
            return output;
        }
    }
}