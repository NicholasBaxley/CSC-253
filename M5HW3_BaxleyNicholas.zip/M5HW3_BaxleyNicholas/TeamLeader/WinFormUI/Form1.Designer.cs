﻿
namespace WinFormUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxNumber = new System.Windows.Forms.TextBox();
            this.textBoxPayrate = new System.Windows.Forms.TextBox();
            this.textBoxShift = new System.Windows.Forms.TextBox();
            this.listBoxOutput = new System.Windows.Forms.ListBox();
            this.labelName = new System.Windows.Forms.Label();
            this.labelNumber = new System.Windows.Forms.Label();
            this.labelShift = new System.Windows.Forms.Label();
            this.labelPayrate = new System.Windows.Forms.Label();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonTeamLeaders = new System.Windows.Forms.Button();
            this.labelAHours = new System.Windows.Forms.Label();
            this.textBoxAHours = new System.Windows.Forms.TextBox();
            this.labelBonus = new System.Windows.Forms.Label();
            this.textBoxBonus = new System.Windows.Forms.TextBox();
            this.labelTHours = new System.Windows.Forms.Label();
            this.textBoxTHours = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(601, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(91, 43);
            this.buttonExit.TabIndex = 0;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(12, 34);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(133, 20);
            this.textBoxName.TabIndex = 1;
            // 
            // textBoxNumber
            // 
            this.textBoxNumber.Location = new System.Drawing.Point(12, 98);
            this.textBoxNumber.Name = "textBoxNumber";
            this.textBoxNumber.Size = new System.Drawing.Size(133, 20);
            this.textBoxNumber.TabIndex = 2;
            // 
            // textBoxPayrate
            // 
            this.textBoxPayrate.Location = new System.Drawing.Point(12, 226);
            this.textBoxPayrate.Name = "textBoxPayrate";
            this.textBoxPayrate.Size = new System.Drawing.Size(133, 20);
            this.textBoxPayrate.TabIndex = 4;
            // 
            // textBoxShift
            // 
            this.textBoxShift.Location = new System.Drawing.Point(12, 162);
            this.textBoxShift.Name = "textBoxShift";
            this.textBoxShift.Size = new System.Drawing.Size(133, 20);
            this.textBoxShift.TabIndex = 3;
            // 
            // listBoxOutput
            // 
            this.listBoxOutput.FormattingEnabled = true;
            this.listBoxOutput.Location = new System.Drawing.Point(330, 88);
            this.listBoxOutput.Name = "listBoxOutput";
            this.listBoxOutput.Size = new System.Drawing.Size(362, 355);
            this.listBoxOutput.TabIndex = 5;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(36, 18);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(84, 13);
            this.labelName.TabIndex = 6;
            this.labelName.Text = "Employee Name";
            // 
            // labelNumber
            // 
            this.labelNumber.AutoSize = true;
            this.labelNumber.Location = new System.Drawing.Point(32, 82);
            this.labelNumber.Name = "labelNumber";
            this.labelNumber.Size = new System.Drawing.Size(93, 13);
            this.labelNumber.TabIndex = 7;
            this.labelNumber.Text = "Employee Number";
            // 
            // labelShift
            // 
            this.labelShift.AutoSize = true;
            this.labelShift.Location = new System.Drawing.Point(22, 146);
            this.labelShift.Name = "labelShift";
            this.labelShift.Size = new System.Drawing.Size(123, 13);
            this.labelShift.TabIndex = 8;
            this.labelShift.Text = "Shift (1 = Day, 2 = Night)";
            // 
            // labelPayrate
            // 
            this.labelPayrate.AutoSize = true;
            this.labelPayrate.Location = new System.Drawing.Point(36, 210);
            this.labelPayrate.Name = "labelPayrate";
            this.labelPayrate.Size = new System.Drawing.Size(76, 13);
            this.labelPayrate.TabIndex = 9;
            this.labelPayrate.Text = "Hourly Payrate";
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(198, 174);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(91, 34);
            this.buttonAdd.TabIndex = 10;
            this.buttonAdd.Text = "Add Team Leader";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonTeamLeaders
            // 
            this.buttonTeamLeaders.Location = new System.Drawing.Point(198, 263);
            this.buttonTeamLeaders.Name = "buttonTeamLeaders";
            this.buttonTeamLeaders.Size = new System.Drawing.Size(91, 34);
            this.buttonTeamLeaders.TabIndex = 11;
            this.buttonTeamLeaders.Text = "Show Team Leaders";
            this.buttonTeamLeaders.UseVisualStyleBackColor = true;
            this.buttonTeamLeaders.Click += new System.EventHandler(this.buttonTeamLeaders_Click);
            // 
            // labelAHours
            // 
            this.labelAHours.AutoSize = true;
            this.labelAHours.Location = new System.Drawing.Point(36, 402);
            this.labelAHours.Name = "labelAHours";
            this.labelAHours.Size = new System.Drawing.Size(81, 13);
            this.labelAHours.TabIndex = 13;
            this.labelAHours.Text = "Attended Hours";
            // 
            // textBoxAHours
            // 
            this.textBoxAHours.Location = new System.Drawing.Point(12, 418);
            this.textBoxAHours.Name = "textBoxAHours";
            this.textBoxAHours.Size = new System.Drawing.Size(133, 20);
            this.textBoxAHours.TabIndex = 12;
            // 
            // labelBonus
            // 
            this.labelBonus.AutoSize = true;
            this.labelBonus.Location = new System.Drawing.Point(36, 274);
            this.labelBonus.Name = "labelBonus";
            this.labelBonus.Size = new System.Drawing.Size(77, 13);
            this.labelBonus.TabIndex = 15;
            this.labelBonus.Text = "Monthly Bonus";
            // 
            // textBoxBonus
            // 
            this.textBoxBonus.Location = new System.Drawing.Point(12, 290);
            this.textBoxBonus.Name = "textBoxBonus";
            this.textBoxBonus.Size = new System.Drawing.Size(133, 20);
            this.textBoxBonus.TabIndex = 14;
            // 
            // labelTHours
            // 
            this.labelTHours.AutoSize = true;
            this.labelTHours.Location = new System.Drawing.Point(36, 338);
            this.labelTHours.Name = "labelTHours";
            this.labelTHours.Size = new System.Drawing.Size(74, 13);
            this.labelTHours.TabIndex = 17;
            this.labelTHours.Text = "Trained Hours";
            // 
            // textBoxTHours
            // 
            this.textBoxTHours.Location = new System.Drawing.Point(12, 354);
            this.textBoxTHours.Name = "textBoxTHours";
            this.textBoxTHours.Size = new System.Drawing.Size(133, 20);
            this.textBoxTHours.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 455);
            this.Controls.Add(this.labelTHours);
            this.Controls.Add(this.textBoxTHours);
            this.Controls.Add(this.labelBonus);
            this.Controls.Add(this.textBoxBonus);
            this.Controls.Add(this.labelAHours);
            this.Controls.Add(this.textBoxAHours);
            this.Controls.Add(this.buttonTeamLeaders);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.labelPayrate);
            this.Controls.Add(this.labelShift);
            this.Controls.Add(this.labelNumber);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.listBoxOutput);
            this.Controls.Add(this.textBoxPayrate);
            this.Controls.Add(this.textBoxShift);
            this.Controls.Add(this.textBoxNumber);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxNumber;
        private System.Windows.Forms.TextBox textBoxPayrate;
        private System.Windows.Forms.TextBox textBoxShift;
        private System.Windows.Forms.ListBox listBoxOutput;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelNumber;
        private System.Windows.Forms.Label labelShift;
        private System.Windows.Forms.Label labelPayrate;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonTeamLeaders;
        private System.Windows.Forms.Label labelAHours;
        private System.Windows.Forms.TextBox textBoxAHours;
        private System.Windows.Forms.Label labelBonus;
        private System.Windows.Forms.TextBox textBoxBonus;
        private System.Windows.Forms.Label labelTHours;
        private System.Windows.Forms.TextBox textBoxTHours;
    }
}

