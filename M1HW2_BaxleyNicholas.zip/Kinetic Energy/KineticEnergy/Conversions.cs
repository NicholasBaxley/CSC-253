﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KineticEnergy
{
    public class Conversions
    {
        // Returns the kinetic energy of the given mass and velocity
        public static double massVelocityToKinetic(double mass, double velocity)
        {
            return ((Math.Pow(velocity, 2)) * mass) / 2;
        }
    }
}
