﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workers
{
    public class Supervisor : Employee
    {
        public decimal annualBonus { get; set; }
        public decimal annualSalary { get; set; }

        public Supervisor(string Name, int Number, decimal AnnualBonus, decimal AnnualSalary) : base(Name, Number)
        {
            annualBonus = AnnualBonus;
            annualSalary = AnnualSalary;
        }
    }
}
