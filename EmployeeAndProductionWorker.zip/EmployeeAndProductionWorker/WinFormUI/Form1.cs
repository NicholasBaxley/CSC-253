﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Workers;

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        //List of all employees
        List<ProductionWorker> employees = new List<ProductionWorker>();

        public Form1()
        {
            InitializeComponent();
        }

        //The close button
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Adds an employee to the output list.
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            //TODO - validate



            string name = textBoxName.Text;
            int number = int.Parse(textBoxNumber.Text); 
            int shift = int.Parse(textBoxShift.Text);
            decimal payrate = decimal.Parse(textBoxPayrate.Text);
            ProductionWorker employee = new ProductionWorker(name, number, shift, payrate);

            employees.Add(employee);
            listBoxOutput.Items.Add("Added Employee!");

        }

        private void buttonEmployees_Click(object sender, EventArgs e)
        {
            
            foreach(ProductionWorker person in employees)
            {
                person.
                listBoxOutput.Items.Add(person);
                listBoxOutput.Items.Add(person);
                listBoxOutput.Items.Add(person);
                listBoxOutput.Items.Add(person);
            }
        }
    }
}
