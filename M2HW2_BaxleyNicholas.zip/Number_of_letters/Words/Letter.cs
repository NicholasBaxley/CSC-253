﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Words
{
    public class Letter
    {
        public static int Count(string sentence)
        {
            int count = 0;

            foreach (char character in sentence)
            {
                if (char.IsLetter(character))
                {
                    count++;
                }
            }

            return count;
        }
    }
}
