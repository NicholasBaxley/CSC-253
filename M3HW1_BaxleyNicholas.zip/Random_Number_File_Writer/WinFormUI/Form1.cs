﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Numbers;

/**
* 9/13/21
* CSC 253
* Nicholas Baxley
* Writes a requested amount of random numbers from 0-100 into a text file
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {

        bool overwriteFlag = false;

        public Form1()
        {
            InitializeComponent();
        }

        // Exit button
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Writes a user requested amount of numbers from 0-100 into the numbers.txt file
        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            int writeTimes;

            try
            {              
                writeTimes = Int32.Parse(textBoxInput.Text);
                if (writeTimes < 0)
                {
                    writeTimes = 0;
                }

                List<int> numberList = RandomNumber.Hundred(writeTimes);
                StreamWriter outputFile = File.CreateText("numbers.txt");

                for (int index = 0; index < writeTimes; index++)
                {
                    outputFile.WriteLine(numberList[index]);
                }

                outputFile.Close();
                textBoxInput.Clear();             
                listBoxOutput.Items.Add(SuccessMessage(writeTimes, overwriteFlag));
                listBoxOutput.TopIndex = listBoxOutput.Items.Count - 1;
                overwriteFlag = true;
            }
            catch (IOException)
            {
                listBoxOutput.Items.Add(IO_InvalidMessage());
            }
            catch (FormatException)
            {
                textBoxInput.Text = Format_InvalidMessage();
            }
            catch (Exception)
            {
                listBoxOutput.Items.Add(InvalidMessage());
            }
        }

        // Removes the invalid message when you click onto the textbox
        private void textBoxInput_MouseClick(object sender, MouseEventArgs e)
        {
            if (textBoxInput.Text == Format_InvalidMessage())
            {
                textBoxInput.Clear();
            }
        }

        // The message that displays when you enter something other than a interger
        public static string Format_InvalidMessage()
        {
            return "Not a valid option!";
        }

        // The message that displays when a file cant be written to, or created
        public static string IO_InvalidMessage()
        {
            return "Somethings seems to have gone wrong when creating the file.";
        }
        // The message that displays when you enter something other than a interger
        public static string InvalidMessage()
        {
            return "An unexpected error occured.";
        }

        // The message that displays when the program executes properly
        public static string SuccessMessage(int write, bool flag)
        {
            if (!flag)
            {
                return $"Wrote to file {write} times.";
            }
            else
            {
                return $"Overwrote file to {write} items.";
            }
        }
    }
}
