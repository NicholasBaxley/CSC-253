﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using People;

/**
* 9/22/21
* CSC 253
* Nicholas Baxley
* Save and load user information into a file.
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The exit button
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Click this to make a new file and reset the names in the list
        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            bool newFile = false;
            CreatePerson(newFile);
        }

        // Click this to add another name to the current list file
        private void buttonFile_Click(object sender, EventArgs e)
        {
            bool newFile = true;
            CreatePerson(newFile);
        }

        // Confirms no names are blank and age is a number then adds the person to the list.
        private void CreatePerson(bool newFile)
        {
            string fName = textBoxFirstName.Text;
            string mName = textBoxMiddleName.Text;
            string lName = textBoxLastName.Text;
            string stringAge = textBoxAge.Text;
            int age;
            Person person;

            if ((fName == "") || (mName == "") || (lName == ""))
            {
                listBoxOutput.Items.Add("Not a valid name!");
            }
            else
            {
                try
                {
                    age = Int32.Parse(stringAge);
                    person = new Person(fName, mName, lName, age);
                    listBoxOutput.Items.Add(Savefile.newPerson(person, newFile));
                }
                catch (Exception)
                {
                    listBoxOutput.Items.Add("Not a valid age!");
                }
            }
            ScrollDown();
        }

        // Displays all people currently in the file
        private void buttonShowPeople_Click(object sender, EventArgs e)
        {
            int count = 0;
            List<Person> people = Loadfile.Load();
            listBoxOutput.Items.Add("====================================================");
            foreach(Person person in people)
            {
                count++;
                listBoxOutput.Items.Add(count + ")");
                listBoxOutput.Items.Add("--------------------");
                listBoxOutput.Items.Add("First: " + person.fName);
                listBoxOutput.Items.Add("Mid:   " + person.mName);
                listBoxOutput.Items.Add("Last:  " + person.lName);
                listBoxOutput.Items.Add("Age:   " + person.age);
                listBoxOutput.Items.Add("");
            }
            ScrollDown();
        }

        // Scrolls to the bottom of the output
        public void ScrollDown()
        {
            listBoxOutput.SelectedIndex = listBoxOutput.Items.Count - 1;
        }
    }
}
