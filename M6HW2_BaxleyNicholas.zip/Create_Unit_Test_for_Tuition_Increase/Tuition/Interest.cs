﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuition
{
    public class Interest
    {
        // Finds how much interest you will own on an amount of money.
        public static double Yearly(double Cost, double interest)
        {
            return Cost * (interest + 1.00);
        }
    }
}
