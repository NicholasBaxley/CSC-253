﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Search;

/**
* 9/13/21
* CSC 253
* Nicholas Baxley
* Tells you what the most frequent letter in a sentence is.
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Exit button
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Displays the most frequent letter
        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            char mostFeqChar = Character.Most_Freq_Char(textBoxInput.Text);
            listBoxOutput.Items.Add("The most frequent character is '" + mostFeqChar + "'");
        }
    }
}
