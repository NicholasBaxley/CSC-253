﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Areas
{
    public class Area
    {
        //Converts the area of a circle
        public static double Convert(double radius)
        {
            return Math.PI * Math.Pow(radius, 2);
        }

        //Converts the area of a rectangle
        public static double Convert(float width, float length)
        {
            return width * length;
        }

        //Converts the area of a cylinder
        public static double Convert(double radius, double height)
        {
            return Math.PI * Math.Pow(radius, 2) * height;
        }
    }
}