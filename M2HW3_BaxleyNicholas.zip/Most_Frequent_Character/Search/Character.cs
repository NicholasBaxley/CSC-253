﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Search
{
    public class Character
    {
        public static char Most_Freq_Char(string sentence)
        {
            char maxLetter = ' ';
            int count = 0;
            int maxCount = 0;
            sentence = sentence.ToLower();


            // Grabs each letter and compares it to every other letter
            foreach (char compareChar in sentence)
            {
                count = 0;
                for (int index = 0; index < sentence.Length; index++)
                {
                    if (compareChar == sentence[index])
                    {
                        count++;
                    }

                    if (count > maxCount)
                    {
                        maxCount = count;
                        maxLetter = sentence[index];
                    }   
                }                    
            }

            return maxLetter;
        }
    }
}
