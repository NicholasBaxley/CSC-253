﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temperture
{
    public class Conversion
    {
        // Turns celsius numbers into fahrenhiet.
        public static double celToFah(int cel)
        {
            return (1.8 * cel) + 32;
        }
    }
}
