﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workers
{
    public class Employee
    {
        string name { get; set; }
        int number { get; set; }

        public Employee(string Name, int Number)
        {
            name = Name;
            number = Number;
        }

        public Employee()
        {
            name = "";
            number = 0;
        }
    }
}
