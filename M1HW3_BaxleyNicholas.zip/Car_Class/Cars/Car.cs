﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cars
{
    public class Car
    {
        private short _year;
        private string _make;
        private double _speed;

        public Car(short year, string make)
        {
            _year = year;
            _make = make;
            _speed = 0;
        }

        public Car()
        {
            _year = 0;
            _make = "Ford";
            _speed = 0;
        }

        public short Year { get; set; }
        public string Make { get; set; }
        public double Speed
        {
            get
            {
                return _speed;
            }

            // Cars speed can not go below 0
            set
            {
                if (value < 0)
                {
                    _speed = 0;
                }
                else
                {
                    _speed = value;
                }
            }
        }

        //Increases speed by set amount
        public void Accelerate(double increase = 5)
        {
            Speed += increase;
        }

        //Lowers speed by set amount
        public void Brake(double decrease = 5)
        {
            Speed -= decrease;
        }
    }
}