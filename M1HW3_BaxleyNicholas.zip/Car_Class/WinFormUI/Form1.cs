﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Cars;

/**
* 8/30/21
* CSC 253
* Nicholas Baxley
* Accelerating and braking a cars speed.
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        Car vehicle = new Car();
        string carSpeedMessage = "Cars speed is: ";

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAccelerate_Click(object sender, EventArgs e)
        {
            vehicle.Accelerate(5);
            labelCarSpeed.Text = carSpeedMessage + vehicle.Speed;
        }

        private void buttonBrake_Click(object sender, EventArgs e)
        {
            vehicle.Brake(5);
            labelCarSpeed.Text = carSpeedMessage + vehicle.Speed;
        }
    }
}
