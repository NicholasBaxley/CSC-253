﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 10/6/2021
* CSC 253
* Nicholas Baxley
* Sorting a dataset in many different ways
*/

namespace WinFormUI
{ 
    public partial class Form1 : Form
    {
        string pattern = "----------------------------------------------------------------------";

        public Form1()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet); 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);
        }

        // The close button
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Sorts the data set by ascending order for population
        private void popAsceSortButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.PopAscendingSort(this.populationDBDataSet.City);
        }

        // Sorts the data set by descending order for population
        private void popDescSortButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.PopDescendingSort(this.populationDBDataSet.City);
        }

        // Sorts the data set by ascending order for city
        private void nameSortButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.CitySort(this.populationDBDataSet.City);
        }

        // Displays the total population
        private void totalPopButton_Click(object sender, EventArgs e)
        {
            outputListBox.Items.Add("The total population is:");
            outputListBox.Items.Add(pattern);
            outputListBox.Items.Add(String.Format("{0:N0}", cityTableAdapter.SumPopulation()));
            outputListBox.Items.Add("");
        }
        
        // Displays the average population
        private void avgPopButton_Click(object sender, EventArgs e)
        {
            outputListBox.Items.Add("The average population is:");
            outputListBox.Items.Add(pattern);
            outputListBox.Items.Add(String.Format("{0:N0}", cityTableAdapter.AvgPopulation()));
            outputListBox.Items.Add("");           
        }

        // Displays the city with the highest population
        private void highPopButton_Click(object sender, EventArgs e)
        {
            outputListBox.Items.Add("The highest population is:");
            outputListBox.Items.Add(pattern);
            outputListBox.Items.Add(String.Format("{0:N0}", cityTableAdapter.MaxPopulation()));
            outputListBox.Items.Add("");
        }

        // Displays the city with the lowest population
        private void lowPopButton_Click(object sender, EventArgs e)
        {
            outputListBox.Items.Add("The lowest population is:");
            outputListBox.Items.Add(pattern);
            outputListBox.Items.Add(String.Format("{0:N0}", cityTableAdapter.MinPopulation()));
            outputListBox.Items.Add("");
        }
    }
}
