﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calculations;

/**
* 11/10/2021
* CSC 253
* Nicholas Baxley
* Using unit tests to make sure a program runs porperly
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_Submit_Click(object sender, EventArgs e)
        {
            bool priceFlag = double.TryParse(textBox_Price.Text, out double price);
            bool percentFlag = double.TryParse(textBox_Percent.Text, out double percent);

            if (priceFlag && percentFlag)
            {
                listBox_Output.Items.Add($"The retail price is: {Retail.GetPrice(price, percent).ToString("C")}");
            }
            else
            {
                listBox_Output.Items.Add("One of the inputs does not have the correct format!");
            }
            
        }
    }
}
