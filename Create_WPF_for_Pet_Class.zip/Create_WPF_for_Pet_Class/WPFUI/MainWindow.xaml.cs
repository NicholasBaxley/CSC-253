﻿using Animals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int currentProcessStep;
        Pet pet;
        List<Pet> pets = new List<Pet>();

        public MainWindow()
        {
            InitializeComponent();
        }

        // Begins or resets the process to add a new animal to the list
        private void button_NewAnimal_Click(object sender, RoutedEventArgs e)
        {
            currentProcessStep = 1;
            pet = new Pet();
            listbox_Guide.Items.Clear();
            listbox_Guide.Items.Add("Enter your pets name.");
        }

        // Grabs the text in the user input box and sends it to the current step in creating a new animal
        private void button_Submit_Click(object sender, RoutedEventArgs e)
        {
            string text = textbox_Input.Text;
            textbox_Input.Text = "";

            switch (currentProcessStep)
            {
                case 1:
                    StepOne(text);
                    break;
                case 2:
                    StepTwo(text);
                    break;
                case 3:
                    StepThree(text);
                    break;
                default:
                    break;
            }
        }

        public void StepOne(string text)
        {
            if (text == "")
            {
                listbox_Guide.Items.Add("You can not leave your pets name empty!");
            }
            else
            {
                pet.name = text;
                currentProcessStep = 2;
                listbox_Guide.Items.Clear();
                listbox_Guide.Items.Add("Now Enter your pet's species.");
            }         
        }

        public void StepTwo(string text)
        {
            if (text == "")
            {
                listbox_Guide.Items.Add("You can not leave your pet's species empty!");
            }
            else
            {
                pet.type = text;
                currentProcessStep = 2;
                listbox_Guide.Items.Clear();
                listbox_Guide.Items.Add("Now Enter your pets age.");
            }
        }

        public void StepThree(string text)
        {
            bool ageFlag = false;
            int age = 0;
            while (!ageFlag || age < 0)
            {
                ageFlag = int.TryParse(Console.ReadLine(), out age);

                if (ageFlag)
                {
                    listbox_Guide.Items.Add("You must enter a whole number!");
                }
                else if (age < 0)
                {
                    listbox_Guide.Items.Add("Your pet's age must be at least 0!");
                }
            }
            pet.age = age;
            pets.Add(pet);

            AddPetToOutput();
        }

        public void AddPetToOutput()
        {
            Pet recentPet = pets[pets.Count - 1];
            listbox_Output.Items.Add($"{pets.Count})");
            listbox_Output.Items.Add("---------------------");
            listbox_Output.Items.Add($"Name: {recentPet.name}");
            listbox_Output.Items.Add($"Type: {recentPet.type}");
            listbox_Output.Items.Add($"Age:  {recentPet.age}");
            listbox_Output.Items.Add("");
        }
    }
}
