﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace People
{
    public class Loadfile
    {
        // Makes a list of all people in the People.csv file and returns it
        public static List<Person> Load()
        {
            List<Person> people = new List<Person>();
            try
            {
                StreamReader outputFile;
                outputFile = File.OpenText("UserInformation.csv");
                while (!outputFile.EndOfStream)
                {
                    string[] token = outputFile.ReadLine().Split(',');
                    people.Add(new Person(token[0], 
                                          token[1],
                                          token[2],
                                          int.Parse(token[3])));
                }
                outputFile.Close();
                return people;

            }
            catch (Exception)
            {
                return people;
            }
        }
    }
}
