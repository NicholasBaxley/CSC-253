﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tuition;

/**
* 11/10/2021
* CSC 253
* Nicholas Baxley
* Doing Unit Tests for Tuition Increase Assignment
*/

namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        // Sets the starting values
        double currentMoney = 6000;
        double percent = .02;
        int year = 1;

        //Adds the intial message in the listbox
        public Form1()
        {
            InitializeComponent();
            listBox_Output.Items.Add("The intial amount is $6,000");
            listBox_Output.Items.Add("with an interest of 2% per year.");
            listBox_Output.Items.Add("__________________________________________________________________________________________________________");
        }

        //Displays the cost of the next five years in the listbox
        private void button_Submit_Click(object sender, EventArgs e)
        {
            for (int index = 0; index < 5; index++, year++)
            {
                currentMoney = Interest.Yearly(currentMoney, percent);
                listBox_Output.Items.Add($"Year:{year} {currentMoney.ToString("C")}");
            }
            listBox_Output.Items.Add("__________________________________________________________________________________________________________");
            listBox_Output.SelectedIndex = listBox_Output.Items.Count - 1;
        }

        //Closes out the program
        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
