﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Words;

/**
* 9/8/21
* CSC 253
* Nicholas Baxley
* Finding the most frequent character in a string
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The close button
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Takes the users text and seperates it then adds it to the listbox
        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            string sepSentence = Word.Separate(textBoxInput.Text);
            listBoxOutPut.Items.Add(sepSentence);
        }
    }
}
