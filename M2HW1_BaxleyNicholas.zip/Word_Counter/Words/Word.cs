﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Words
{
    public class Word
    {
        //Counts the amount of words in a sentence.
        public static int Count(string sentence)
        {
            char[] delim = {' '};
            string[] tokens;
            int count = 0;

            sentence = sentence.Trim();
            tokens = sentence.Split(delim);

            //Makes sure empty strings arent counted as words.
            foreach(string word in tokens)
            {
                if (word != "")
                {
                    count++;
                }
            }

            return count;
        }
    }
}
