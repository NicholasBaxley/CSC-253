﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Words;

/**
* 9/2/21
* CSC 253
* Nicholas Baxley
* Counts the amount of words in a sentence
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Close Button
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Calls Count method and resets textbox
        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            CountWords();

            //Scrolls the listbox down and resets textbox
            listBoxOutput.SelectedIndex = listBoxOutput.Items.Count - 1;
            textBoxInput.Text = "";
        }

        //Prints the amount of words into the output
        public void CountWords()
        {
            //Counts the words
            int wordAmount = Word.Count(textBoxInput.Text);

            //Writes the output
            listBoxOutput.Items.Add(textBoxInput.Text);
            listBoxOutput.Items.Add(wordAmount + " words in your sentence.");
            listBoxOutput.Items.Add("");
        }
    }
}
