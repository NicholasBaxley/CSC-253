﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Workers;

/**
* 10/25/2021
* CSC 253
* Nicholas Baxley
* Add and displays Team Leaders from a list.
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        // List of all leaders for global use.
        List<TeamLeader> leaders = new List<TeamLeader>();

        public Form1()
        {
            InitializeComponent();
        }

        // The close button.
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Adds an employee to the output list.
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            // Add variable and validate them
            string name = textBoxName.Text;
            bool numberFlag = int.TryParse(textBoxNumber.Text, out int number);
            bool shiftFlag = int.TryParse(textBoxShift.Text, out int shift) && (shift == 1 || shift == 2);
            bool payRateFlag = decimal.TryParse(textBoxPayrate.Text, out decimal payRate);
            bool bonusFlag = decimal.TryParse(textBoxBonus.Text, out decimal bonus);
            bool tHoursFlag = int.TryParse(textBoxTHours.Text, out int tHours);
            bool aHoursFlag = int.TryParse(textBoxAHours.Text, out int aHours);

            // Tells user if item didnt validate.
            if (!numberFlag)
            {
                listBoxOutput.Items.Add("Employee number must be an interger!");
            }
            if (!shiftFlag)
            {
                listBoxOutput.Items.Add("Employee Shift must 1 or 2!");
            }
            if (!payRateFlag)
            {
                listBoxOutput.Items.Add("Employee Payrate must be a decimal!");
            }
            if (!bonusFlag)
            {
                listBoxOutput.Items.Add("Monthly Bonus must be a decimal!");
            }
            if (!tHoursFlag)
            {
                listBoxOutput.Items.Add("Trained Hours must be a interger!");
            }
            if (!aHoursFlag)
            {
                listBoxOutput.Items.Add("Attended Hours must be a interger!");
            }

            // If all validate, adds leaders to list.
            if (numberFlag && shiftFlag && payRateFlag && bonusFlag && tHoursFlag && aHoursFlag)
            {
                leaders.Add(new TeamLeader(bonus, tHours, aHours, name, number, shift, payRate));
                listBoxOutput.Items.Add("Added Employee!");
            }           
        }

        // Clears the output box and displays all leaders.
        private void buttonTeamLeaders_Click(object sender, EventArgs e)
        {
            listBoxOutput.Items.Clear();
            foreach (TeamLeader person in leaders)
            {               
                listBoxOutput.Items.Add("----------------------");
                listBoxOutput.Items.Add("Name: " + person.name);
                listBoxOutput.Items.Add("Employee ID: " + person.number);

                if (person.shift == 1)
                {
                    listBoxOutput.Items.Add("Day Shift");
                }
                else
                {
                    listBoxOutput.Items.Add("Night Shift");
                }

                listBoxOutput.Items.Add("Hourly Pay: " + person.payrate);
                listBoxOutput.Items.Add("Monthly Bonus: " + person.monthlyBonus);
                listBoxOutput.Items.Add("Trained Hours: " + person.trainedHours);
                listBoxOutput.Items.Add("Attended Hours: " + person.attendedHours);
                listBoxOutput.Items.Add("");
            }
        }
    }
}