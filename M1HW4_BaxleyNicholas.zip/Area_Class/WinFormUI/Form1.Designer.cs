﻿
namespace WinFormUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.listBoxOutput = new System.Windows.Forms.ListBox();
            this.buttonCylinderSelect = new System.Windows.Forms.Button();
            this.buttonRectangleSelect = new System.Windows.Forms.Button();
            this.buttonCircleSelect = new System.Windows.Forms.Button();
            this.buttonSubmit = new System.Windows.Forms.Button();
            this.textBoxInput1 = new System.Windows.Forms.TextBox();
            this.textBoxInput2 = new System.Windows.Forms.TextBox();
            this.labelInput1 = new System.Windows.Forms.Label();
            this.labelInput2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(487, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(101, 65);
            this.buttonExit.TabIndex = 6;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // listBoxOutput
            // 
            this.listBoxOutput.FormattingEnabled = true;
            this.listBoxOutput.Location = new System.Drawing.Point(331, 116);
            this.listBoxOutput.Name = "listBoxOutput";
            this.listBoxOutput.Size = new System.Drawing.Size(257, 225);
            this.listBoxOutput.TabIndex = 7;
            // 
            // buttonCylinderSelect
            // 
            this.buttonCylinderSelect.Location = new System.Drawing.Point(197, 54);
            this.buttonCylinderSelect.Name = "buttonCylinderSelect";
            this.buttonCylinderSelect.Size = new System.Drawing.Size(75, 23);
            this.buttonCylinderSelect.TabIndex = 2;
            this.buttonCylinderSelect.Text = "Cylinder";
            this.buttonCylinderSelect.UseVisualStyleBackColor = true;
            this.buttonCylinderSelect.Click += new System.EventHandler(this.buttonCylinderSelect_Click);
            // 
            // buttonRectangleSelect
            // 
            this.buttonRectangleSelect.Location = new System.Drawing.Point(103, 54);
            this.buttonRectangleSelect.Name = "buttonRectangleSelect";
            this.buttonRectangleSelect.Size = new System.Drawing.Size(75, 23);
            this.buttonRectangleSelect.TabIndex = 1;
            this.buttonRectangleSelect.Text = "Rectangle";
            this.buttonRectangleSelect.UseVisualStyleBackColor = true;
            this.buttonRectangleSelect.Click += new System.EventHandler(this.buttonRectangleSelect_Click);
            // 
            // buttonCircleSelect
            // 
            this.buttonCircleSelect.Enabled = false;
            this.buttonCircleSelect.Location = new System.Drawing.Point(12, 54);
            this.buttonCircleSelect.Name = "buttonCircleSelect";
            this.buttonCircleSelect.Size = new System.Drawing.Size(75, 23);
            this.buttonCircleSelect.TabIndex = 0;
            this.buttonCircleSelect.Text = "Circle";
            this.buttonCircleSelect.UseVisualStyleBackColor = true;
            this.buttonCircleSelect.Click += new System.EventHandler(this.buttonCircleSelect_Click);
            // 
            // buttonSubmit
            // 
            this.buttonSubmit.Location = new System.Drawing.Point(15, 305);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.Size = new System.Drawing.Size(87, 28);
            this.buttonSubmit.TabIndex = 5;
            this.buttonSubmit.Text = "Submit";
            this.buttonSubmit.UseVisualStyleBackColor = true;
            this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // textBoxInput1
            // 
            this.textBoxInput1.Location = new System.Drawing.Point(12, 163);
            this.textBoxInput1.Name = "textBoxInput1";
            this.textBoxInput1.Size = new System.Drawing.Size(100, 20);
            this.textBoxInput1.TabIndex = 3;
            this.textBoxInput1.Click += new System.EventHandler(this.textBoxInput1_Click);
            // 
            // textBoxInput2
            // 
            this.textBoxInput2.Enabled = false;
            this.textBoxInput2.Location = new System.Drawing.Point(172, 163);
            this.textBoxInput2.Name = "textBoxInput2";
            this.textBoxInput2.Size = new System.Drawing.Size(100, 20);
            this.textBoxInput2.TabIndex = 4;
            this.textBoxInput2.Click += new System.EventHandler(this.textBoxInput2_Click);
            // 
            // labelInput1
            // 
            this.labelInput1.AutoSize = true;
            this.labelInput1.Location = new System.Drawing.Point(12, 147);
            this.labelInput1.Name = "labelInput1";
            this.labelInput1.Size = new System.Drawing.Size(40, 13);
            this.labelInput1.TabIndex = 8;
            this.labelInput1.Text = "Radius";
            // 
            // labelInput2
            // 
            this.labelInput2.AutoSize = true;
            this.labelInput2.Location = new System.Drawing.Point(169, 147);
            this.labelInput2.Name = "labelInput2";
            this.labelInput2.Size = new System.Drawing.Size(0, 13);
            this.labelInput2.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 345);
            this.Controls.Add(this.labelInput2);
            this.Controls.Add(this.labelInput1);
            this.Controls.Add(this.textBoxInput2);
            this.Controls.Add(this.textBoxInput1);
            this.Controls.Add(this.buttonSubmit);
            this.Controls.Add(this.buttonCircleSelect);
            this.Controls.Add(this.buttonRectangleSelect);
            this.Controls.Add(this.buttonCylinderSelect);
            this.Controls.Add(this.listBoxOutput);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.ListBox listBoxOutput;
        private System.Windows.Forms.Button buttonCylinderSelect;
        private System.Windows.Forms.Button buttonRectangleSelect;
        private System.Windows.Forms.Button buttonCircleSelect;
        private System.Windows.Forms.Button buttonSubmit;
        private System.Windows.Forms.TextBox textBoxInput1;
        private System.Windows.Forms.TextBox textBoxInput2;
        private System.Windows.Forms.Label labelInput1;
        private System.Windows.Forms.Label labelInput2;
    }
}

